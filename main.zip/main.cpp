/* 
 * File:   main.cpp
 * Author: owner
 *
 * Created on October 22, 2015, 10:10 PM
 */

#include <cstdlib>
#include <iostream>
#include <cmath>
#include <string>
#include <cassert>

using namespace std;

int getProductOfDigits( int );
void getPersistence( int );
void outputPersistence( int, int );

int main() 
{
    int userNum; //Integer that will store the user inputted number
    do
    {
        cout << "Please give me a non-negative integer: ";
        cin >> userNum;
        if(userNum < 0)
        {
            cout << "ERROR: Only non-negative integers please." << endl;
        }
        cout << endl;
    }
    while(userNum < 0);
    
    //cout << userNum << " -> ";
    
    getPersistence(userNum);
    
    return 0;
}

void getPersistence( int userNum )
{
    int persistence = 0;
    int userNum1 = userNum;
    cout << userNum;
    while( userNum > 9)
    {
        cout << " -> ";
        int product = 1;
        for( int i = userNum; i > 0; i/= 10)
        {
            product *= (userNum % 10);
            userNum /= 10;
        }
        userNum = product;
        cout << product;
        persistence++;
    }
    cout << endl;
    cout << "The persistence of " << userNum1 << " is " << persistence << ".";
}

/*int persistence;
    persistence = getDigits(userNum);
    //cout << userNum << " -> " << getProductOfDigits( userNum ) << " -> " << getProductOfDigits(getProductOfDigits( userNum )) << " -> " << getProductOfDigits(getProductOfDigits(getProductOfDigits( userNum ))) << endl;
    //cout << "The persistence of " << userNum << " is " << persistence << "." << endl;
//    for( int i = 0; i < )
    do
    {
        getProductOfDigits( userNum );
    }
    while(userNum < 10);*/

